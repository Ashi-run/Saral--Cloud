const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, QueryCommand } = require("@aws-sdk/lib-dynamodb");

const docClient = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TABLE_NAME = "SaralData";

function getGroups(claims) {
  const raw = claims["cognito:groups"];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === "string") return raw.replace(/[[\]]/g, "").split(",").map((g) => g.trim()).filter(Boolean);
  return [];
}
const json = (statusCode, obj) => ({ statusCode, headers: { "Content-Type": "application/json" }, body: JSON.stringify(obj) });

exports.handler = async (event) => {
  try {
    const claims = event.requestContext.authorizer.jwt.claims;
    const companyId = claims["custom:companyId"];
    if (!companyId) return json(403, { error: "This user has no company assigned." });
    const groups = getGroups(claims);
    if (!groups.includes("Owner") && !groups.includes("Manager")) return json(403, { error: "Only Owners and Managers can view team members." });

    const r = await docClient.send(new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :p)",
      ExpressionAttributeValues: { ":pk": `COMPANY#${companyId}`, ":p": "TEAM#" },
    }));
    const members = (r.Items || []).map((i) => ({
      userId: i.userId, email: i.email, role: i.role, invitedAt: i.invitedAt,
    }));
    // make sure the caller always sees themselves
    if (!members.some((m) => m.userId === claims.sub)) {
      members.unshift({ userId: claims.sub, email: claims.email, role: groups[0] || "Owner", invitedAt: null });
    }
    return json(200, { members });
  } catch (err) {
    console.error(err);
    return json(500, { error: "Something went wrong fetching team members: " + (err.name || "") });
  }
};
