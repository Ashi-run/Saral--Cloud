const { CognitoIdentityProviderClient, AdminCreateUserCommand, AdminSetUserPasswordCommand, AdminAddUserToGroupCommand } = require("@aws-sdk/client-cognito-identity-provider");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");

const cognito = new CognitoIdentityProviderClient({});
const docClient = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TABLE_NAME = "SaralData";
const USER_POOL_ID = "ap-south-1_2oMIw4H23";
const VALID_ROLES = ["Manager", "SalesExec", "CollectionExec", "WarehouseStaff"];

function getGroups(claims) {
  const raw = claims["cognito:groups"];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === "string") return raw.replace(/[[\]]/g, "").split(",").map((g) => g.trim()).filter(Boolean);
  return [];
}
const json = (statusCode, obj) => ({ statusCode, headers: { "Content-Type": "application/json" }, body: JSON.stringify(obj) });

exports.handler = async (event) => {
  try {
    const claims = event.requestContext.authorizer.jwt.claims;
    const companyId = claims["custom:companyId"];
    if (!companyId) return json(403, { error: "This user has no company assigned." });
    if (!getGroups(claims).includes("Owner")) return json(403, { error: "Only Owners can invite team members." });

    const { email, role, tempPassword } = JSON.parse(event.body || "{}");
    if (!email || !role || !tempPassword) return json(400, { error: "email, role and tempPassword are required." });
    if (!VALID_ROLES.includes(role)) return json(400, { error: `Invalid role. Valid roles: ${VALID_ROLES.join(", ")}.` });

    const created = await cognito.send(new AdminCreateUserCommand({
      UserPoolId: USER_POOL_ID,
      Username: email,
      TemporaryPassword: tempPassword,
      MessageAction: "SUPPRESS",
      UserAttributes: [
        { Name: "email", Value: email },
        { Name: "email_verified", Value: "true" },
        { Name: "custom:companyId", Value: companyId },
      ],
    }));
    await cognito.send(new AdminSetUserPasswordCommand({ UserPoolId: USER_POOL_ID, Username: email, Password: tempPassword, Permanent: true }));
    await cognito.send(new AdminAddUserToGroupCommand({ UserPoolId: USER_POOL_ID, Username: email, GroupName: role }));

    const sub = (created.User.Attributes || []).find((a) => a.Name === "sub")?.Value || email;
    await docClient.send(new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        PK: `COMPANY#${companyId}`, SK: `TEAM#${sub}`,
        userId: sub, email, role, companyId,
        invitedBy: claims.sub, invitedAt: new Date().toISOString(),
      },
    }));
    return json(201, { message: "User invited successfully", userId: sub });
  } catch (err) {
    console.error(err);
    if (err.name === "UsernameExistsException") return json(409, { error: "User with this email already exists." });
    if (err.name === "InvalidPasswordException") return json(400, { error: "Password too weak: use 8+ chars with upper, lower, number and symbol." });
    return json(500, { error: "Something went wrong inviting the user: " + (err.name || "") });
  }
};
